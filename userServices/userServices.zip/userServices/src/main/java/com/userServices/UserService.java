package com.userServices;


public interface UserService {
    User saveUser(User user);

    ResponseDto getUser(Long userId);
}
 